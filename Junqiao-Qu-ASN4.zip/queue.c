//CSCI 3120 Assignment4
//Junqiao Qu B00817232
//jqu jn679016
//Citation:
// Created by QuJunqiao for CSCI2122 (2020Fall)
// Revised  by QuJunqiao for CSCI3120

#include <stdlib.h>
#include "queue.h"
#include <string.h>
#include <stdio.h>
Queue* queue_initialize(int typeSize, char* type){
    Queue *q = malloc(sizeof(Queue));
    q->arr = (void **) malloc(999*sizeof(void*));
    q->typeSize = typeSize;
    q->type = type;
    q->front=0;
    q->rear=0;
    q->size = 0;
    q->maxSize=0;
    return q;
}
bool queue_enqueue(Queue* q, void* data){
    if (q!=NULL&&data!=NULL) {



        q->arr[q->rear] = data;
        q->rear += 1 ;
        q->size += 1;
        q->maxSize+=1;
        return true;
    } else {
        return false;
    }
}
void* queue_dequeue(Queue* q){
    if (q!=NULL&&q->size>0) {


        q->front+=1;
        q->size -= 1;
        return q->arr[q->front];
    }

}
void* queue_peek(Queue* q){
    if (q!=NULL&&q->size>0) {



        return q->arr[q->front];
    }
}
int queue_size(Queue* q){
    if (q){
        return q->size;
    }}

bool queue_contains(Queue* q, void* data){
    bool flag=false;
    if (q != NULL && data != NULL ) {
        for (int i=q->front;i<q->rear;i++){
            if(memcmp(q->arr[i],data,sizeof(void*))==0){
                flag=true;
            }
        }
    }
    return flag;

}
bool queue_destroy(Queue* q){
    if (q) {
        for(int i=0;i<q->maxSize;i++){
            free(q->arr[i]);}
        free(q->arr) ;

        free(q);

        return true;
    } else {
        return false;
    }
}
