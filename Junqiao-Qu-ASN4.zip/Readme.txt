To compile this file, please use command
gcc -o A4 main.c heap.c queue.c array_list.c task.c 
Then run the exe, please use command
./A4