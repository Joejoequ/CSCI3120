//CSCI 3120 Assignment4
//Junqiao Qu B00817232
//jqu jn679016

#ifndef INC_3120A4_TASK_H
#define INC_3120A4_TASK_H
#include <stdbool.h>
//Task Structure is used to record task status
typedef struct _Task{
    char* taskName;
    int arrival;
    int burstTime;
    int waitingTime;
    int remainingTime;

}Task;

//ExecTask Structure is used to record each execution of Task
typedef struct _ExecTask{
   Task* task;
   int start;
   int end;
}ExecTask;


Task * Task_initialize(char*,int,int);
ExecTask * ExecTask_initialize(Task*,int,int);
#endif //INC_3120A4_TASK_H
