//CSCI 3120 Assignment4
//Junqiao Qu B00817232
//jqu jn679016

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "task.h"
#include "queue.h"
#include "heap.h"

Task *Tokenize(char *);


void FCFS(Task **, int);

void RR(Task **, int);

void NPSJF(Task **, int);

void PSJF(Task **, int);

int remainingCompare(void *, void *);

int burstCompare(void *, void *);

FILE * pOutput;

int main() {
    //get all task to be scheduled from file and store them in a list
    FILE *pInput;
    pInput = fopen("TaskSpec.txt", "r");
    pOutput=fopen("Output.txt","w");
    char *input = malloc(99 * sizeof(char));

    Task **taskList = malloc(50 * sizeof(Task *));
    int listSize = 0;
    while (fgets(input, 99, pInput) != NULL) {
        Task *task = Tokenize(input);
        taskList[listSize] = task;
        listSize++;
    }
    //use task information in list, schedule in FCFS
    FCFS(taskList, listSize);
    //use task information in list, schedule in RoundRobin
    RR(taskList, listSize);
    //use task information in list, schedule in Non-preemptive Shortest Job First
    NPSJF(taskList, listSize);
    //use task information in list, schedule in Preemptive Shortest Job First
    PSJF(taskList, listSize);

    return 0;
}

// initialize a task from an input line
Task *Tokenize(char *inputStr) {
    char *result[3];
    char *input;
    input = malloc(99 * sizeof(char));
    strcpy(input, inputStr);
    result[0] = strtok(input, ",");
    for (int i = 1; i < 3; i++) {
        result[i] = strtok(NULL, ",");
    }
    Task *task = Task_initialize(result[0], atoi(result[1]), atoi(result[2]));
    return task;
}

void FCFS(Task **tasklist, int size) {
    //deep copy of tasklist, no changes in original list
    Task **list = malloc(50 * sizeof(Task *));
    for (int i = 0; i < size; i++) {
        Task *temp = malloc(sizeof(Task));
        memcpy(temp, tasklist[i], sizeof(Task));
        list[i] = temp;
    }

    fprintf(pOutput,"FCFS:\n");
    int timer = 0;
    int taskNum = 0;
    int previousEndTime = 0;

    //schedule each task in list, output start, end time, and record waiting time of each task
    while (taskNum < size) {
        if (list[taskNum]->arrival <= timer && timer >= previousEndTime) {
            fprintf(pOutput,"%s\t%d\t%d\n", list[taskNum]->taskName, timer, timer + list[taskNum]->burstTime);
            list[taskNum]->waitingTime = timer - list[taskNum]->arrival;
            previousEndTime = timer + list[taskNum]->burstTime;
            taskNum++;
        }
        timer++;
    }

    //output the waiting time
    int totalWaitingTime = 0;
    for (int i = 0; i < taskNum; i++) {
        fprintf(pOutput,"Waiting Time %s: %d\n", list[i]->taskName, list[i]->waitingTime);
        totalWaitingTime += list[i]->waitingTime;
    }
    fprintf(pOutput,"Average Waiting Time: %.2f\n\n", totalWaitingTime * 1.0 / taskNum);


}

void RR(Task **tasklist, int size) {
    //deep copy of tasklist, no changes in original list
    Task **list = malloc(50 * sizeof(Task *));
    for (int i = 0; i < size; i++) {
        Task *temp = malloc(sizeof(Task));
        memcpy(temp, tasklist[i], sizeof(Task));
        list[i] = temp;
    }
    //first in first out queue
    Queue *queue = queue_initialize(sizeof(Task), "Task");
    fprintf(pOutput,"RR:\n");
    int timer = 0;
    int counter = 0;

    //use exectask to record each execution in queue
    ExecTask **execTaskList = malloc(999 * sizeof(ExecTask *));
    queue_enqueue(queue, list[0]);

    while (true) {
        //check if all task complete
        int remain = 0;
        for (int i = 0; i < size; i++) {
            remain += list[i]->remainingTime;
        }

        //if all task finished, quit
        if (remain == 0) {
            break;
        }

        // check if there is a task arrive at this time
        for (int i = 0; i < size; i++) {
            if (list[i]->arrival == timer && !queue_contains(queue, list[i]) && list[i]->remainingTime != 0) {
                queue_enqueue(queue, list[i]);
            }
        }

        //if no task in ready queue
        if (queue_size(queue) == 0) {
            timer++;
            continue;
        }

        Task *task = (Task *) queue_peek(queue);
        int duration = 4;

        // if task to be scheduled has less remaining time than quantum
        if (task->remainingTime < 4) {
            duration = task->remainingTime;
        }
        //add task to ExecTaskList, which hold the history of task executed
        execTaskList[counter] = ExecTask_initialize(task, timer, timer + duration);
        task->remainingTime -= duration;

        //update timer
        timer += duration;
        for (int i = 0; i < size; i++) {
            //if there is a task arrive during execution, enqueue first
            if (list[i]->arrival <= timer && !queue_contains(queue, list[i]) && list[i]->remainingTime != 0) {
                queue_enqueue(queue, list[i]);
            }
        }

        //if not finished, enqueue the task again
        if (task->remainingTime > 0) {
            queue_enqueue(queue, task);
        }
        queue_dequeue(queue);

        //count the size of ExecTaskList
        counter++;


    }

    //output the execution tasks
    for (int i = 0; i < counter; i++) {
        fprintf(pOutput,"%s\t%d\t%d\n", execTaskList[i]->task->taskName, execTaskList[i]->start, execTaskList[i]->end);
    }

    //output the waiting time
    int totalWaitingTime = 0;
    for (int i = 0; i < size; i++) {
        int waitingStart = list[i]->arrival;
        for (int j = 0; j < counter; j++) {
            if (strcmp(execTaskList[j]->task->taskName, list[i]->taskName) == 0) {
                list[i]->waitingTime += execTaskList[j]->start - waitingStart;
                waitingStart = execTaskList[j]->end;
            }
        }
        fprintf(pOutput,"Waiting Time %s: %d\n", list[i]->taskName, list[i]->waitingTime);
        totalWaitingTime += list[i]->waitingTime;
    }
    fprintf(pOutput,"Average Waiting Time: %.2f\n\n", totalWaitingTime * 1.0 / size);

}

void NPSJF(Task **tasklist, int size) {
    //deep copy of tasklist, no changes in original list
    Task **list = malloc(50 * sizeof(Task *));
    for (int i = 0; i < size; i++) {
        Task *temp = malloc(sizeof(Task));
        memcpy(temp, tasklist[i], sizeof(Task));
        list[i] = temp;
    }

    //priority queue, always put task that has shortest burst at first
    ExecTask **execTaskList = malloc(999 * sizeof(ExecTask *));
    fprintf(pOutput,"NSJF:\n");
    Heap *readyQueue = heap_initialize(sizeof(Task), "Task", burstCompare, NULL);

    int timer = 0;
    int taskNum=0;
    int previousEndTime = 0;
    int counter = 0;

    while (counter < size) {

        //check if there is task arrived
        while (taskNum < size && timer == list[taskNum]->arrival) {
            heap_insert(readyQueue, list[taskNum]);
            taskNum++;
        }
        //if ready queue is empty
        if (timer < previousEndTime || heap_size(readyQueue) == 0) {
            timer++;
            continue;
        }

        //execute shortest job in ready queue
        Task *task = malloc(sizeof(Task));
        memcpy(task, heap_peek(readyQueue), sizeof(Task));
        execTaskList[counter] = ExecTask_initialize(task, timer, timer + task->burstTime);
        previousEndTime = timer + task->burstTime;
        heap_remove(readyQueue);
        counter++;
    }
    //output the exectask list
    for (int i = 0; i < counter; i++) {
        fprintf(pOutput,"%s\t%d\t%d\n", execTaskList[i]->task->taskName, execTaskList[i]->start, execTaskList[i]->end);
    }

    //calculate waiting time
    int totalWaitingTime = 0;
    for (int i = 0; i < size; i++) {
        int waitingStart = list[i]->arrival;
        for (int j = 0; j < counter; j++) {
            if (strcmp(execTaskList[j]->task->taskName, list[i]->taskName) == 0) {
                list[i]->waitingTime += execTaskList[j]->start - waitingStart;
                waitingStart = execTaskList[j]->end;
            }
        }
        fprintf(pOutput,"Waiting Time %s: %d\n", list[i]->taskName, list[i]->waitingTime);
        totalWaitingTime += list[i]->waitingTime;
    }
    fprintf(pOutput,"Average Waiting Time: %.2f\n\n", totalWaitingTime * 1.0 / size);

}
//compare each task's burst time
int burstCompare(void *p1, void *p2) {
    Task *t1 = (Task *) p1;
    Task *t2 = (Task *) p2;
    if (t1->burstTime > t2->burstTime) {
        return -1;
    } else if (t1->burstTime == t2->burstTime) {
        if (t1->arrival>t2->arrival){
            return -1;
        }
        else if (t1->arrival<t2->arrival){
            return 1;
        }
        else{
        return 0;}
    }
    return 1;
}

void PSJF(Task **tasklist, int size) {
    //deep copy of tasklist, no changes in original list
    Task **list = malloc(50 * sizeof(Task *));
    for (int i = 0; i < size; i++) {
        Task *temp = malloc(sizeof(Task));
        memcpy(temp, tasklist[i], sizeof(Task));
        list[i] = temp;
    }

    //use priority queue, always put task that has shortest remaining time at first
    ExecTask **execTaskList = malloc(999 * sizeof(ExecTask *));
    fprintf(pOutput,"PSJF:\n");
    Heap *readyQueue = heap_initialize(sizeof(Task), "Task", remainingCompare, NULL);

    int timer = 0;
    int taskNum = 0;
    int previousEndTime = 0;
    int counter = 0;

    while (true) {
        //check if all task complete
        int remain = 0;
        for (int i = 0; i < size; i++) {
            remain += list[i]->remainingTime;
        }

        //if all task finished, quit
        if (remain == 0) {
            break;
        }
        //check if there is task arrived at this time
        while (taskNum < size && timer == list[taskNum]->arrival) {
            heap_insert(readyQueue, list[taskNum]);
            taskNum++;
        }
        //if readyqueue is empty, idle
        if (heap_size(readyQueue) == 0) {
            timer++;
            continue;
        }
        //select task that has shortest remaining time
        Task *task = malloc(sizeof(Task));
        memcpy(task, heap_peek(readyQueue), sizeof(Task));

        //if Shortest Task is same as previous task, just add 1 to end time of previous task in ExecTaskList
        if (counter > 0 && strcmp(execTaskList[counter - 1]->task->taskName, task->taskName) == 0) {
            counter--;
            execTaskList[counter]->end += 1;
        }
        //if different, create a new exectask to list
        else {
            execTaskList[counter] = ExecTask_initialize(task, timer, timer + 1);
        }
        for (int i = 0; i < size; i++) {
            if (strcmp(list[i]->taskName, execTaskList[counter]->task->taskName) == 0) {
                list[i]->remainingTime -= 1;
            }
        }

        task->remainingTime -= 1;
        heap_remove(readyQueue);
        if (task->remainingTime > 0) {
            heap_insert(readyQueue, task);
        }
        timer++;
        counter++;
    }
    //output the start and end time for each executed task
    for (int i = 0; i < counter; i++) {
        fprintf(pOutput,"%s\t%d\t%d\n", execTaskList[i]->task->taskName, execTaskList[i]->start, execTaskList[i]->end);
    }

    //calculate the waiting time
    int totalWaitingTime = 0;
    for (int i = 0; i < size; i++) {
        int waitingStart = list[i]->arrival;
        for (int j = 0; j < counter; j++) {
            if (strcmp(execTaskList[j]->task->taskName, list[i]->taskName) == 0) {
                list[i]->waitingTime += execTaskList[j]->start - waitingStart;
                waitingStart = execTaskList[j]->end;
            }
        }
        fprintf(pOutput,"Waiting Time %s: %d\n", list[i]->taskName, list[i]->waitingTime);
        totalWaitingTime += list[i]->waitingTime;
    }
    fprintf(pOutput,"Average Waiting Time: %.2f\n\n", totalWaitingTime * 1.0 / size);

}

//compare the remaining time of each task
int remainingCompare(void *p1, void *p2) {
    Task *t1 = (Task *) p1;
    Task *t2 = (Task *) p2;
    if (t1->remainingTime > t2->remainingTime) {
        return -1;
    } else if (t1->remainingTime == t2->remainingTime) {
        if (t1->arrival>t2->arrival){
            return -1;
        }
        else if (t1->arrival<t2->arrival){
            return 1;
        }
        else{
            return 0;}
        
    }
    return 1;
}








