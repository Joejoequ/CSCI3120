//CSCI 3120 Assignment4
//Junqiao Qu B00817232
//jqu jn679016


#include "task.h"
#include <stdlib.h>
#include <string.h>
Task * Task_initialize(char* id,int arrival,int burst){
    Task* task=malloc(sizeof(Task));
    char* input=malloc(99*sizeof(char));
    strcpy(input,id);
    task->taskName=input;
    task->arrival=arrival;
    task->burstTime=burst;
    task->remainingTime=burst;
    task->waitingTime=0;

    return task;
}

ExecTask * ExecTask_initialize(Task* task,int start,int end){
    ExecTask* execTask=malloc(sizeof(ExecTask));
    execTask->task=task;
    execTask->start=start;
    execTask->end=end;
    return execTask;
}
