//CSCI 3120 Assignment5
//Junqiao Qu B00817232
//jqu jn679016

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define  BUFFER_SIZE  5
typedef int buffer_item;
buffer_item buffer[BUFFER_SIZE];
//next location to insert
int in = 0;
//next location could be removed
int out = 0;
//semaphore
pthread_mutex_t mutex;
sem_t empty;
sem_t full;

void insert_item(buffer_item);

int remove_item();

void *producer(void *);

void *consumer(void *);

typedef struct _Para {
    int index;
} Parameter;


void *producer(void *param) {
    Parameter *p = (Parameter *) param;
    buffer_item item;

    while (true) {
        /* sleep for a random period of time: 0-4 seconds */
        int randomSleep = rand() % 5;
        sleep(randomSleep);
        /* generate a random number */
        item = rand();

        //if array is full, then wait
        //if other thread is operating on the array, then wait
        sem_wait(&empty);
        pthread_mutex_lock(&mutex);
        /* insert an item */
        printf("Producer %d inserted item %d into buffer[%d]\n", p->index, item, in);
        insert_item(item);
        //release the lock
        pthread_mutex_unlock(&mutex);
        sem_post(&full);
    }
}

void *consumer(void *param) {

    Parameter *p = (Parameter *) param;

    while (true) {
        /* sleep for a random period of time: 0-4 seconds */
        int randomSleep = rand() % 5;
        sleep(randomSleep);
        //if array is empty, then wait
        //if other thread is operating on the array, then wait
        sem_wait(&full);
        pthread_mutex_lock(&mutex);
        /* remove an item */
        int removeIndex = out;
        int item = remove_item();
        printf("Consumer %d consumed item %d from buffer[%d]\n", p->index, item, removeIndex);
        pthread_mutex_unlock(&mutex);
        sem_post(&empty);
    }
}
//insert an item according to the rule
void insert_item(buffer_item num) {
    buffer[in] = num;
    in = (in + 1) % 5;
}
//remove an item according to the rule
int remove_item() {
    int temp = buffer[out];
    buffer[out] = -1;
    out = (out + 1) % 5;
    return temp;
}

int main(int argc, char *argv[]) {
    //initialize
    for (int i = 0; i < 4; i++) {
        buffer[i] = -1;
    }

    int mainSleepTime = atoi(argv[1]);
    int producerNum = atoi(argv[2]);
    int consumerNum = atoi(argv[3]);
    //initialize semaphore
    pthread_mutex_init(&mutex, NULL);
    sem_init(&empty, 0, 5);
    sem_init(&full, 0, 0);
    //initialize threads
    pthread_t producerThread[producerNum];
    pthread_t consumerThread[consumerNum];
    //create producer threads
    for (int i = 0; i < producerNum; i++) {
        Parameter *p = malloc(sizeof(Parameter));
        p->index = i;
        pthread_create(&producerThread[i], NULL, producer, p);
    }
    //create consumer threads
    for (int i = 0; i < consumerNum; i++) {
        Parameter *p = malloc(sizeof(Parameter));
        p->index = i;
        pthread_create(&consumerThread[i], NULL, consumer, p);
    }

    //main thread sleep for a time , then terminate
    sleep(mainSleepTime);
    pthread_mutex_destroy(&mutex);

    return 0;
}
