To compile this file, please use command
gcc -o A5 main.c -lpthread -lrt
Then run the program, please use command. There has to be 3 integer passed to main (argv), or it will cause segmentation fault

./A5 mainSleeptime producerNumber consumerNumber

Example
./A5 10 2 1