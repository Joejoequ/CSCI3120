//
// Created by 曲俊侨 on 2021/10/6.
//
#include "command.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
CommandList *CommandList_initialize() {
    CommandList *list = malloc(sizeof(CommandList));
    list->first = NULL;
    list->last = NULL;
    list->size=0;
    return list;
}

bool CommandList_add_first(CommandList *list, Command* cmd) {
    if (list != NULL && cmd != NULL) {
        Node *n = malloc(sizeof(Node));
        n->command = cmd;
        if (list->first == NULL) {
            n->prev = NULL;
            n->next = NULL;
            list->first = n;
            list->last = n;
        } else {
            n->prev = NULL;
            n->next = list->first;
            list->first->prev = n;
            list->first = n;
        }
        list->size += 1;
        return true;

    } else {
        return false;
    }
}

void CommandList_remove_last(CommandList *list) {
    if (list != NULL)  {
        if (list->size > 0) {
            Node *second_last = list->last->prev;
            second_last->next = NULL;
            list->last = second_last;
            list->size -= 1;
        }
    }
}

void CommandList_print(CommandList *list) {
    if (list) {
        if (list->size!=0) {
            Node *temp = malloc(sizeof(Node));
            temp = list->first;
            int count = 0;
            printf("ID\tPID\tCommand\n");

            while (count < list->size) {

                Command *cmd = temp->command;
                printf("%d\t%d\t%s\n", count + 1, cmd->pid, cmd->input);

                if (temp->next == NULL) {
                    break;
                } else {
                    count++;
                    temp = temp->next;
                }
            }
        }
        else{
            printf("No command in history!\n");
        }
    }

}

Command *CommandList_get(CommandList *list, int index) {
    if (list != NULL && index >= 0 && index < list->size) {
        Node *temp;
        if (index == 0) {
            return list->first->command;

        } else {
            temp = list->first;
            while (index != 0) {
                temp = temp->next;
                index--;
            }

            return temp->command;
        }
    } else {
        return NULL;
    }

}
bool CommandList_update(CommandList *list,int pid,char* input) {
    if (list){

        Command *cmd = malloc(sizeof(Command));

        cmd->input=malloc(80*sizeof(char));
        strcpy(cmd->input,input);
        cmd->pid=pid;
        CommandList_add_first(list,cmd);
        if (list->size>10){
            CommandList_remove_last(list);
        }

        return true;


    }
    else{
        return false;
    }
}




