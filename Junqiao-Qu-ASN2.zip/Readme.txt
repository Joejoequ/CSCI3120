To compile this file, please use command
gcc -o A2 main.c command.c 
Then run the exe, please use command
./A2