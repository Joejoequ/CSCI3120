//
// Created by 曲俊侨 on 2021/10/6.
//

#ifndef A2_COMMAND_H
#define A2_COMMAND_H
#include <stdbool.h>
typedef struct _Command{
    int pid;
    char* input;
}Command;
typedef struct _Node{
    Command * command;
    struct _Node* next;
    struct _Node* prev;
}Node;

typedef struct _CommandList{
    Node*  first;
    Node* last;
    int size;
}CommandList;

CommandList* CommandList_initialize();
bool CommandList_add_first(CommandList*, Command*);
void CommandList_remove_last(CommandList*);
void CommandList_print(CommandList *);
Command *CommandList_get(CommandList *, int);

bool CommandList_update(CommandList *,int ,char* );
#endif //A2_COMMAND_H
