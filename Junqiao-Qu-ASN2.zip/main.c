#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "command.h"
#include <ctype.h>
#include <sys/wait.h>

#define MAX_LINE 80

char **Tokenize();

int main() {

    char **args;
    int should_run = 1;
    int execvp_status;
    int wait_status;
    CommandList *list = CommandList_initialize();
    while (should_run) {
        printf("CSCI3120>");
        fflush(stdout);
        args=malloc((MAX_LINE / 2 + 1)*sizeof(char));
        char input[MAX_LINE];
        fgets(input, MAX_LINE, stdin);

        char *inputCommand;

        inputCommand = strtok(input, "\n");


        args=Tokenize(input);

        if (args[0][0] == '!') {
            if (args[0][1] == '!') {
                Command *recentCommand =CommandList_get(list,0);
                if (!recentCommand){
                    printf("No command in history!\n");
                    continue;
                }
                args=Tokenize(recentCommand->input);
                inputCommand=recentCommand->input;
            }
            if (isdigit(args[0][1])) {
                strcpy(args[0],args[0]+1);
                Command *recentCommand =CommandList_get(list,atoi(args[0]) - 1);
                if (!recentCommand){
                    printf("No command in history!\n");
                    continue;
                }
                args=Tokenize(recentCommand->input);
                inputCommand=recentCommand->input;


            }
        }

        if (strcmp(args[0], "history") == 0) {

            CommandList_print(list);
        } else if (strcmp(args[0], "exit") == 0) {
            should_run = 0;
        }

        else {
            pid_t pid;
            pid = fork();

            CommandList_update(list, pid,  inputCommand);
            if (pid < 0) {
                fprintf(stderr, "Fork Failed");
                return 1;
            } else if (pid == 0) {

                execvp_status = execvp(args[0], args);
                if (execvp_status == -1) {
                    printf("Invalid Command!\n");
                    exit(1);
                }
                }

            else {
                wait(&wait_status);

            }
        }

    }


return 0;


}

char **Tokenize(char * inputStr) {
    char** result;
    char* input;
    input=malloc(MAX_LINE*sizeof(char));
    result=malloc((MAX_LINE / 2 + 1)*sizeof(char*));
    strcpy(input,inputStr);

    result[0] = strtok(input, " \n");
    int i = 0;
    while (result[i] != NULL) {
        i++;
        //subsequent call of strtok, use NULL as parameter
        result[i] = strtok(NULL, " \n");
    }
    return result;
}

