//CSCI 3120 Assignment3
//Junqiao Qu B00817232
//jqu jn679016

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <math.h>

typedef struct {
    int starting_index;
    int ending_index;

} parameters;

void *sorter(void *params);

void *merger(void *params);

int *Tokenize(char *inputStr);

void insertionSort(int arr[], int start, int end);

int *numArray;
int arrayEndingIndex;
int *sortedArray;

int main() {
    //get input integer array from file
    FILE *pFile;
    pFile = fopen("IntegerList.txt", "r");
    char input[9999];
    fgets(input, 9999, pFile);
    numArray = Tokenize(input);


    sortedArray = malloc(500 * sizeof(int));
    int mid = ceil(arrayEndingIndex / 2.0);

    //create parameter for sorting thread 1
    parameters *sort1 = (parameters *) malloc(sizeof(parameters));
    sort1->starting_index = 0;
    sort1->ending_index = mid - 1;
    //create parameter for sorting thread 2
    parameters *sort2 = (parameters *) malloc(sizeof(parameters));
    sort2->starting_index = mid;
    sort2->ending_index = arrayEndingIndex;

    pthread_t tid1;
    pthread_t tid2;
    pthread_t tid3;
    //create 2 sorting threads
    pthread_create(&tid1, NULL, sorter, sort1);
    pthread_create(&tid2, NULL, sorter, sort2);
    //wait for end of soring thread
    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);
    //create merging thread
    pthread_create(&tid3, NULL, merger, sort2);
    //waiting for end of merging thread
    pthread_join(tid3, NULL);

    //output the sorted list to a file
    FILE *fp = fopen("SortedIntegerList.txt", "w");
    for (int i = 0; i < arrayEndingIndex; i++) {
        fprintf(fp, "%d,", sortedArray[i]);
    }
    fprintf(fp, "%d", sortedArray[arrayEndingIndex]);

    return 0;
}

void *sorter(void *params) {
    parameters *param = (parameters *) params;
    insertionSort(numArray, param->starting_index, param->ending_index);
}
//choose smaller value between left and right sublist
//add remaining of another sublist when reach a sublist's end
void *merger(void *params) {
    parameters *param2 = (parameters *) params;
    int i = 0;
    int j = param2->starting_index;
    int k = 0;
    while (k <= param2->ending_index) {
        if (i > param2->starting_index - 1) {
            sortedArray[k] = numArray[j];
            j++;
        } else if (j > param2->ending_index) {
            sortedArray[k] = numArray[i];
            i++;
        } else {
            if (numArray[i] < numArray[j]) {
                sortedArray[k] = numArray[i];
                i++;
            } else {
                sortedArray[k] = numArray[j];
                j++;
            }
        }
        k++;
    }
}

//InsertionSort
//Cite: Revised based on https://www.geeksforgeeks.org/insertion-sort/
void insertionSort(int arr[], int start, int end) {
    int i, key, j;
    for (i = start; i <= end; i++) {
        key = arr[i];
        j = i - 1;

        /* Move elements of arr[0..i-1], that are
          greater than key, to one position ahead
          of their current position */
        while (j >= start && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
//create an int array from the input string, split by comma
int *Tokenize(char *inputStr) {
    int *result;
    char *input;
    input = malloc(9999 * sizeof(char));
    result = malloc(500 * sizeof(int));
    strcpy(input, inputStr);

    result[0] = atoi(strtok(input, ","));
    int i = 0;
    while (1) {
        i++;
        //subsequent call of strtok, use NULL as parameter
        char *nextStr = strtok(NULL, ",");
        if (nextStr == NULL) {
            i--;
            break;
        }
        result[i] = atoi(nextStr);
    }
    arrayEndingIndex = i;
    return result;
}




