Assume there exist an IntegerList.txt, if not it will cause an error

To compile this file, please use command
gcc -lm -o A3 A3.c -lpthread
Then run the exe, please use command
./A3