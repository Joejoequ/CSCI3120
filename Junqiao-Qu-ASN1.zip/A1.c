#include <stdio.h>
#include <string.h>
/*
 * CSCI  3120 A1
 * Qu Junqiao B00817232
 */
int main() {
    //initialize the string variable for user input, 9999 for enough memory space
    char str[9999];
    //get user input from keyboard
    printf("Please Enter Your Sentence:");
    gets(str);
    //split the sentence using delimiter " "
    char *word;
    word = strtok(str, " ");
    //create a file
    FILE *fp = fopen("Output.txt", "w");
    while (word != NULL) {
        //display word on screen and save it to file
        printf("%s\n", word);
        fprintf(fp, "%s\n", word);
        //subsequent call of strtok, use NULL as parameter
        word = strtok(NULL, " ");
    }
    //close the file
    fclose(fp);

    return 0;
}
