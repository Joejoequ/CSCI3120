To compile this file, please use command
gcc -o A1 A1.c 
Then run the exe, please use command
./A1

